#include<stdio.h>
int main(){
	int i,j,n,m,k=0;
	//k ni ijil bgaa elementuudiig tooloh tooluuriin utga hadgalagch
	printf("1<=n<=100 nohtsoliig hangah husnegtiin baganii  n toogoo oruulna uu n = \n");
	scanf("%d",&n);
	int A[n];
	printf("husnegtiinhee elementuudee oruulna uu\n");
	for(i=0;i<n;i++){
		scanf("%d",&A[i]);
	}
	printf("1<=m<=100 nohtsoliig hangah husnegtiin baganii  m toogoo oruulna uu m = \n");
	scanf("%d",&m);
	int B[m];
	printf("husnegtiinhee elementuudee oruulna uu\n");
	for(i=0;i<m;i++){
		scanf("%d",&B[i]);
	}
	printf("hoyr husnegted zereg baigaa elementuud : ");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			if(A[i]==B[j]){
				printf("%d  ",A[i]);
			}
		}
	}
	
	return 0;
}

#include<stdio.h>
int main(){
	int n,m,i,j,k;
	
	printf("n toogoo oruulna uu\n");
	printf("n = ");
	scanf("%d",&n);
	int A[n];
	printf("A husnegtiin %d elementuuee oruulna uu\n",n);
	for(i=0;i<n;i++){
		scanf("%d",&A[i]);
	}
	
	printf(" m toogoo oruulna uu\n");
	printf("m = ");
	scanf("%d",&m);
	int B[m];
	printf("B husnegtiin %d elementuudee oruulna uu\n",m);
	for(i=0;i<m;i++){
		scanf("%d",&B[i]);
	}
	//zowhon A husnegt dotor dawhardsan element bgaa esehiig shalgana
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(A[i]==A[j]){
				k=j;	
				for(k=j;k<n-1;k++){
					A[k]=A[k+1];
				}
				n=n-1;
				j=j-1;
			}	
		}
	}
	printf("A husnegtiin dawhtsalgui helber\n");
	for(i=0;i<n;i++){
		printf("%d  ",A[i]);
	}
	printf("\n");
	
	
	//zowhon B husnegt dotor dawhardsan element bgaa esehiig shalgana
	for(i=0;i<m;i++){
		for(j=i+1;j<m;j++){
			if(B[i]==B[j]){
				k=j;	
				for(k=j;k<m-1;k++){
					B[k]=B[k+1];
				}
				m--;
				j--;
			}	
		}
	}
	printf("B husnegtiin dawhtsalgui helber\n");
	for(i=0;i<m;i++){
		printf("%d  ",B[i]);
	}
	printf("\n");
	// A ba B husnegt hoyuland ni zereg orson baigaa elementiig hasah
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			if(A[i]==B[j]){
				k=j;
				for(k=j;k<m;k++){
					B[k]=B[k+1];
				}
				m--;
				j--;
			}
		}
	}
	j=0;
	int C[n+m+1];
	for(i=0;i<n;i++){
		C[j]=A[i];
		j++;
	}
	for(i=0;i<m;i++){
		C[j]=B[i];
		j++;
	}
	printf("\n");	
	printf("C husnegtiin elementuud : \n");
	for(i=0;i<(n+m);i++){
		printf("%d ",C[i]);
	}
	return 0;
}

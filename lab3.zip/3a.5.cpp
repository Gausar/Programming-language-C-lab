#include<stdio.h>
int main(){
	int i,n,k=0,g=0,d=0;
	printf("1<= n < 100 baih n toogoo oruulna uu? (Husnegtiin hemjeeg zaana)\n");
	scanf("%d,",&n);
	int A[n];
	
	printf("husnegtiin elementee oruulna uu\n");
	for(i=0;i<n;i++){
		printf("A[%d] = ",i);
		scanf("%d",&A[i]);
	}
	for(i=0;i<n;i++){
		if(A[i]==A[i+1]){
			d++;
		}
		else if(A[i]<A[i+1]){
			k++;
		}
		else if(A[i]>A[i+1]){
			g++;
		}
	}
	//printf("%d%d%d",d,k,g);
	if((k+d)==(n)){
		printf("Osohoor eremblegdsen husnegt bn\n");
	}
	else if((g+d)==(n)){
		printf("Buurahaar eremmblegdsen bn\n");
	}
	else printf("erembegui husnegt bn");
	
	return 0;
}

#include<stdio.h>
int palindrom(int a);
int main(){
	int a;
	scanf("%d",&a);
	if(palindrom(a)==1){
		printf("palindrom too mon bn\n");
	}
	else printf("palindrom too bish bn\n");
}
int palindrom(int a){
	int b,r;
	b=a;
	int s=0;
	while(b>0){
		r=b%10;
		s=s*10+r;
		b=b/10;
	}
	if(s==a){
		return 1;
	}
	return 0;
	
}

#include<stdio.h>
int main(){
	int i,n,x,s=0;
	printf("1<= n <= 100 baih n toogoo oruulna uu\n");
	scanf("%d",&n);
	int A[n];
	printf("A husnegtiinhee elementuudee oruulna uu\n");
	for(i=0;i<n;i++){
		scanf("%d",&A[i]);
	}
	printf("oloh gej bgaa x toogoo oruulna uu\n");
	scanf("%d",&x);
	
	for(i=0;i<n;i++){
		if(A[i]==x){
			printf("x toonii bairlal : ");
			printf("%d  ",i);
			s++;
		}
	}
	if(s==0){
		printf("-1");
	}
	return 0;
}

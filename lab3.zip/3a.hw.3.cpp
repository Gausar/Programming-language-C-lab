#include<stdio.h>
int main(){
	int m,k,n,i,j,g;
	//dawhariin too - n
	//ortsnii too - k
	//dawhar buriiin ailiinn too - m
	printf("ailiin too, ortsnii too, dawhariin too\n");
	printf("dawhar burt bgaa ailiin too = ");
	scanf("%d",&m);
	printf("ortsnii too = ");
	scanf("%d",&k);
	printf("dawhariin too = ");
	scanf("%d",&n);
	int A[m][k][n];
	//niit ailiin too - s
	int s=1;
	//hamgiin gadna ortsnii toog awsan
	for(i=0;i<k;i++){
		//2dahi ni dawhargiin too
		for(j=0;j<n;j++){
			//ailiin toog iltgej bgaa
			for(g=0;g<m;g++){
				A[i][j][g]=s;
				s=s+1;
			}
		}
	}
	printf("A[orts][dawhar][haalga] = \n");
	for(i=0;i<k;i++){
		for(j=0;j<n;j++){
			for(g=0;g<m;g++){
				printf("A[%d][%d][%d] = %d   ",i,j,g,A[i][j][g]);
			}
			printf("\n");
		}
		printf("\n");
	}
	
	return 0;
}

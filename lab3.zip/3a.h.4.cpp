#include<stdio.h>
int main(){
	int i,j,n,d;
	
	printf("n toogoo oruulaarai\n");
	scanf("%d",&n);
	int A[n][n],k=0;
	for(i=0;i<n;i++){
	
		for(j=0;j<n;j++){
			if(k<n){
				A[i][j]=k+1;
				k=k+1;
				d=j;
			}
			else {
				for(j=d+1;j<n;j++){
					
					A[i][j]=k-1;
					k=k-1;
				}
			}
		}
		k=i+1;
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			printf("%d ",A[i][j]);
		}
		printf("\n");
	}
	return 0;
}

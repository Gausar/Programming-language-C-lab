#include<stdio.h>
int main(){
	int i,n;
	printf("1<=n<100 baih n toog oruulna uu\n n = ");
	scanf("%d",&n);
	int A[n];
	for(i=0;i<n;i++){
		scanf("%d",&A[i]);
	}
	
	for(i=n-1; i>=0; i--){
		
		printf("%d  ",A[i]);
		
	}
	return 0;
}

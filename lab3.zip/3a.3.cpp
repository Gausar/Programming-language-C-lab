#include<stdio.h>
int main(){
	int n,m,i,j;
	
	printf("1<=n<100 baih n toogoo oruulna uu\n");
	printf("n = ");
	scanf("%d",&n);
	printf("1<= m <100 baih m toogoo oruulna uu\n");
	printf("m = ");
	scanf("%d",&m);
	int A[n];
	printf("A husnegtiin %d elementuuee oruulna uu\n",n);
	for(i=0;i<n;i++){
		printf("A[%d] = ",i);
		scanf("%d",&A[i]);
	}
	int B[m];
	printf("B husnegtiin %d elementuuee oruulna uu\n",m);
	for(i=0;i<m;i++){
		printf("B[%d] = ",i);
		scanf("%d",&B[i]);
	}
	int C[n+m];
	j=0;
	for(i=0;i<n;i++){
		C[j]=A[i];
		j++;
	}
	for(i=0;i<m;i++){
			C[j]=B[i];
			j++;
			}
	printf("C husnegtiin elementuud : \n");
	for(i=0;i<(n+m);i++){
		printf("%d ",C[i]);
	}
		return 0;
	}


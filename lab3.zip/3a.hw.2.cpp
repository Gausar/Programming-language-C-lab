#include<stdio.h>
int main(){
	int n,i,j,s;
	
	printf("husnegtiin hemjees n toogoo oruulna uu\n");
	scanf("%d",&n);
	int A[n][n];
	printf("husnegtiin element tus buriig oruulaarai\n");
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			printf("A[%d][%d] = ",i,j);
			scanf("%d",&A[i][j]);
		}
	}
	//mor buriin niilber oloh
	for(i=0;i<n;i++){
		s=0;
		for(j=0;j<n;j++){
			s=s+A[i][j];
		}
		printf("%d moriin niilber = %d \n",i,s);
	}
	//bagana buriin niilberiig oloh
	for(j=0;j<n;j++){
		s=0;
		for(i=0;i<n;i++){
			s=s+A[i][j];
		}
		printf("%d baganii elementuudiin niilber = %d\n",j,s);
	}
	//zuun diagonoli
	s=0;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(i==j){
				s=s+A[i][j];
			}
		}
	}
	printf("zuun diagonaliin elementuudiin niilber = %d\n",s);
	//baruun diagonali
	int p=0;
	i=0;
	for(j=n-1;j>=0;j--){
			p=p+A[i][j];
			i++;
	}
	printf("baruun diagonaliin elementuudiin niilber = %d\n",p);
	
	return 0;
}

#include<stdio.h>
int main(){
	int i, A[10];
	for(i=1;i<=10;i++){
		A[i]=i;
	}
	
	for(i=1;i<=10;i++){
		printf("%d ",A[i]);	
	}
	return 0;		
}

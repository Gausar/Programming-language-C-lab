#include<stdio.h>
int main(){
	int i,j,n,m,s=0,x;
//s-d dawtagdaj baigaa x toog toolj hadgalna
	printf("Husnegtiinhee hemjeesee oruulna uu\n");
	printf(" moriin too n = ");
	scanf("%d",&n);
	printf("baganaii too m = ");
	scanf("%d",&m);
	int A[n][m];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			printf("A[%d][%d] = ",i,j);
			scanf("%d",&A[i][j]);
		}
	}
	printf("X toogoo oruulna uu x = ");
	scanf("%d",&x);
	printf("%d toonii husnegt dehi bairlaluud (mor,Bagana)\n",x);
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			if(A[i][j]==x){
				printf("%d mornii %d bagana\n",i,j);
				s++;
			}
		}	
	}
	if(s==0){
		printf("1,-1");
	}
return 0;	
}

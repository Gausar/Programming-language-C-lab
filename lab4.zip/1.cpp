#include<stdio.h>

int gcd(int a, int b);
int min(int a, int b);

int main(){
	int a,b;
	printf("hoyr toogoo oruulna uu : \n");
	scanf("%d%d",&a,&b);
	printf("%d ba %d hoyr toonii HIEH ni\t: ",a,b);
	printf("%d",gcd(a,b));
	return 0;
}
int min(int a, int b){
	if(a<b){
		return a;
	}
	else return b;
}
int gcd(int a, int b){
	int i,j;
	for(i=1;i<min(a,b);i++){
		if(a%i==0){
			if(b%i==0){
				j=i;
			}
		}
	}
	return j;
}

#include<stdio.h>
int A[100];
int digit_sum(int n);
int main(){
	int n,i;
	printf("n = ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		if(digit_sum(i)!=0){
			printf("%d\t",digit_sum(i));
		}
		else;
	}
	return 0;
}

int digit_sum(int i){
	int r,s=0,a=i;
	while(a>0){
		r=a%10;
		s=s+r;
		a=a/10;
	}
	if(i%s==0){
		return i;
	}
	return 0;
}

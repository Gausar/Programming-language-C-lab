#include<stdio.h>
int palindrom(int a);
int main(){
	int a;
	printf("toogoo oruulna uu\n");
	scanf("%d",&a);
	printf("%d",palindrom(a));
	return 0;
}
int palindrom(int a){
	int b;
	b=a;
	int s=0,r;
	while(b>0){
		r=b%10;
		s=s*10+r;
		b=b/10;
	}
	if(s==a){
		return 1;
	}
	return 0;
}

#include<stdio.h>
void read( int A[], int n);
void sort(int A[], int n);
void print(int A[], int n);
int main(){
	int n, too[100];
	scanf("%d",&n);
	read(too,n);
	sort(too,n);
	print(too,n);
	return 0;
}
void read( int A[], int n){
	printf("husnegtiin elementuudee oruulaarai\n");
	for(int i=0; i<n;i++){
		scanf("%d",&A[i]);
	}
}
void sort(int A[], int n){
	for(int i=0; i<n-1;i++){
		int m=i;
		for(int j=i+1; j<n; j++){
			if(A[j] > A[m]){
				m=j;
			}
		}
		if(m!=i){
			int d=A[i];
			A[i]=A[m];
			A[m]=d;
		}	
	}	
}
void print(int A[], int n){
	printf("sort hiisen husnegt : \n");
	for(int i=0;i<n;i++){
		printf("%d",A[i]);
	}
}


#include<stdio.h>
int power(int a, int n);
int main(){
	int t=1;
		int n,a;
		scanf("%d%d",&a,&n);
		
		printf("%d\n",power(a,n));
		return 0;
}

int power(int a, int n){
	int i,t=1;
	for(i=1;i<=n;i++){
		t*=a;
	}
	return t;
}

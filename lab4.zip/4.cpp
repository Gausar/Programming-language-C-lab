#include<stdio.h>

int A[100];
int prime_range(int a, int b){
	int s=0;
	for(int i=a;i<=b;i++){
		int count =0;
		for(int j=1;j<=i;j++){
			if(i%j==0){
				count++;
			}
	}
	if(count==2){
		A[s]=i;
		s++;
	}
	}
	return s;
}
int main(){
	int a,b;
	printf("a ba b hoyr toogoo oruulaarai\n");
	scanf("%d%d",&a,&b);
	printf("ankhnii toonuud ni : ");
	for(int i=0;i<prime_range(a,b);i++){
		printf("%d\t",A[i]);
	}
	
	printf("\n%d ba %d zawsar dahi niit bgaa ankhnii too : %d",a,b,prime_range(a,b));
	return 0;
}

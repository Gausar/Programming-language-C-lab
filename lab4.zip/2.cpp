#include<stdio.h>
int min1(int a,int b);
int min2(int c, int d, int e);

int main(){
	int a,b,c,d,e;
	printf("5-n toogoo oruulaarai\n");
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	
	if(min1(a,b)>min2(c,d,e)){
		printf("hamgiin baga ni : %d",min2(c,d,e));
	}
	else printf("hamgiin baga ni : %d",min1(a,b));
	return 0;
}

int min1(int a, int b){
	if(a>b){
		return b;
	}
	else return a;
}
int min2(int c, int d, int e){
	if((c<d)&&(c<e)){
		return c;
	}
	if((d<c)&&(d<e)){
		return d;
	}
	if((e<c)&&(e<d)){
		return e;
	}
}



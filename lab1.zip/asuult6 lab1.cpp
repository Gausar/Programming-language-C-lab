#include<stdio.h>
#include<math.h>
int main(){
	//yzguur doorh uildliig tusdaa k usgeer temdeglew.
	//yrunhii ilerhiileliig mun s usgeer temdeglesen
	float a,b,c,d,k,s;
	scanf("%f %f %f %f", &a, &b, &c, &d);
	k=sqrt(pow(a+b,2)+d);
	s=k/c;
	printf("%.4f",s);
	return 0;
	 
}

#include<stdio.h>
#include<math.h>
//asuult 2.b
#define PI 3.14
int main(){
	float a,b,c;
	double x;
	printf("gurvaljnii hoyr tal bolon ontsgoo oruulna uu");
	scanf("%f %f %lf",&a,&b, &x);
	
	c=sqrt(pow(b,2)+pow(a,2)-2*a*b*cos(x*PI/180));
	
	printf("%f",c);
	return 0;
}

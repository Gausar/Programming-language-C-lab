#include<stdio.h>

int main(){
//asuult1	
	printf("sain baina uu? C hel\n");
	
//asuult 2
	int a,b,c;
	a=2018;
	b=2;
	c=5;
	printf("Onoodor %d oni %d sariin %d-nii odor\n",a,b,c);
	
//asuult 3
	int y=2002,m=10,d=1;
	printf("Bi %d onii %d sariin %d odor torson\n",y,m,d);
	
//asuult 4
#include<stdio.h>
int main(){
	int e,f,g;
	scanf("%d %d %d", &e, &f, &g);
	printf("Onoodor %d onii %d sariin %d odor\n",e,f,g);
	return 0;
}
//asuult 5
#include<stdio.h>
int main(){
	float k,p;
	scanf("%f %f",k,p);
	printf("k+p=%.2f\n",k+p);
	printf("k-p=%.2f\n",k-p);
	printf("k*p=%.2f\n",k*p);
	printf("k/p=%.2f\n",k/p);
	printf("k%p=%.2f",k%p);
	retyrn 0;
}
//asuult 6
	float
}

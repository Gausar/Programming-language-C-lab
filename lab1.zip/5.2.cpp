#include<stdio.h>
#include<math.h>
int main(){
	int a,b,c;
	float d;
	printf("a,b hoyr toogoo oruulna uu\n");
	scanf("%d %d \n",&a,&b);
	c=a+b;
	printf("a b c %d%d%d\n",a,b,c);
	c=a-b;
	printf("a b c= %d%d%d\n",a,b,c);
	c=a*b;
	printf("a b c= %d%d%d\n",a,b,c);
	d=a/b;
	printf("a b d= %d%d %.2f\n",a,b,d);
	c=a%b;
	printf("a b c= %d%d%d",a,b,c);
	
	return 0;
}

#include<stdio.h>
int main(){
	int y=2018, m= 2, d=5;
	printf("Onoodor %d onii %d sariin %d odor", y,m,d);
	
	return 0;
}

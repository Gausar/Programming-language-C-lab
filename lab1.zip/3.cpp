#include<stdio.h>
int main(){
	int y=2002, m= 10, d=1;
	printf("Onoodor %d onii %d sariin %d odor", y,m,d);
	
	return 0;
}

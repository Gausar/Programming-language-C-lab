#include<stdio.h>
int main(){
	int y,m,d;
	y=2018;
	m=2;
	d=5;
	printf("Onoodor %d oni %d sariin %d-nii odor",y,m,d);
	return 0;
}

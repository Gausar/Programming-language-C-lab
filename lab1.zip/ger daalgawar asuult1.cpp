#include<stdio.h>

int main(){
	float a,h,s;
	scanf("%f %f",&a,&h);
	s=a*h/2;
	printf("Talbai=%.2f",s);
	return 0;
}

#include<stdio.h>
#include<math.h>
//asuult 2.a
int main(){
	float a,b,c,d,s,k;
	scanf("%f %f %f %f",&a, &b, &c, &d);
	k=sqrt(pow((pow(a,3)+(b/c)),2)+d);
	s=k/(pow(d,2)-(a*b)/c)*d;
	
	printf("%f",s);
	return 0;
}

#include<stdio.h>

int main(){
	int a,h,s;
	scanf("%d",a);
	scanf("%d",h);
	s=a*h/2;
	printf("Talbai=%d",s);
	return 0;
}

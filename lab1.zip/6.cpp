#include<stdio.h>
#include<math.h>
int main(){
	int a,b,c,d;
	float m,n,s;
	printf("a,b,c,d buhel toonuudaa oruulna uu\n");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	m=pow((a+b),2);
	n=sqrt(m+d);
	s=n/c;
	printf("%.4f",s);
	
	
	return 0;
}

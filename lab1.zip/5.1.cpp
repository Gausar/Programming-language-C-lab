#include<stdio.h>
#include<math.h>
int main(){
	int a,b;
	printf("a,b hoyr toogoo oruulna uu\n");
	scanf("%d %d",&a,&b);
	printf("a+b = %d\n",a+b);
	printf("a-b = %d\n",a-b);
	printf("a*b = %d\n",a*b);
	printf("a/b = %.2f\n",(a/(float)b));
	printf("a%b = %d",a%b);
	
	return 0;
}

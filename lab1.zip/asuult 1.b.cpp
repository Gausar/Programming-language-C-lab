//asuult 1.b
#include<stdio.h>
#include<math.h>

int main(){
	float a,b,c,x1,x2,disc;
	scanf("%f %f %f",&a,&b,&c);
	disc=pow(b,2)-(4*a*c);
	if(disc>0){
		x1=(-b+sqrt(disc))/(2*a);
		x2=(-b-sqrt(disc))/(2*a);
			printf("x1=%.2f x2=%.2f",x1,x2);
	}
	else if(disc==0){
		x1=(-b)/(2*a);
			printf("x1=%f",x1);
	}
	else printf("shiidgui");
	
	return 0;
}

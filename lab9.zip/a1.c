#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main() {
    FILE *ftext;
    ftext = fopen("wikiMongolia.txt", "r");
    if (!ftext) {
        printf("aldaa\n");
        exit(1);
    }
    
    fseek(ftext, 0L, SEEK_END); //heden temdegt bgaag shalgasan
    long int hemjee = ftell(ftext);
    printf("niit temdegtiin too : %ld\n", hemjee);
    
    fseek(ftext, 0, SEEK_SET);
        //rewind(ftext); gej bichij bas bolno.
    // char text[1500];
    // char * fgets(ftext, text);
    // printf("%s", text);


    char eh[1500] = {0};
    int i = 0;
    int c;
    while ((c = fgetc(ftext)) != EOF) { //fgetc ni integer utga butsaadag tul c-g int toroltei zarlasan
        eh[i++] = (char)c;
    }
    fclose(ftext);
        //fgetc() функц нь файлын дараагийн тэмдэгтийг уншиж, утгыг нь int хэлбэрээр буцаадаг.
        //fgetc() нь EOF утгыг буцаана
            
    //printf("sizeof eh = %d\n", sizeof(eh));
    printf("eh temdegtiin ehnii useg : %c\n", eh[0]);
    FILE *finfo;
    finfo = fopen("wikituhai.txt", "w");
    if(!finfo){
        printf("medeelel bichih uyed aldaa uslee\n");
        exit(1);
    }

    int ugiinToo = 1;
    for(i =0; i<strlen(eh); i++){
        if(eh[i] == ' ' || eh[i] == '\0'){
            ugiinToo++;
        }
    }
    printf("ugiin too = %d\n", ugiinToo);
    char ugs[]="ugiin too = ";

    int oguulber = 0;
    for(i = 0; i < strlen(eh); i++){
        if(eh[i] == '.' || eh[i] == '?' || eh[i] == '!'){
            oguulber++;
        }
    }
    printf("oguulberiin too = %d\n", oguulber);
    char oguul[]="oguulberiin too = ";


    char urtUg[50] = "";
    char ug[50] = "";
    int max = 0;
    int j=0;
    for(i = 0; i < strlen(eh); i++){
        if((eh[i] >= 65 && eh[i] <= 90 ) || (eh[i] >= 97 && eh[i] <= 122)){
            ug[j] = eh[i];
            j++;
        }
        else{
            if(max < j){
            max = j;
            strcpy(urtUg, ug);
            }
            j=0;
        }
    }
    printf("hamgiin urt ug ni : %s", urtUg);
    char urt[]="hamgiin urt ug : ";
    
    fputs(ugs, finfo);
    fprintf(finfo, "%d\n", ugiinToo);
    fputs(oguul, finfo);
    fprintf(finfo, "%d\n", oguulber);
    fputs(urt, finfo);
    fputs(urtUg, finfo);
    return 0;
}

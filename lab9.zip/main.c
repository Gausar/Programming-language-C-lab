#include <stdio.h>
#include <stdlib.h>
struct Student {
        char name[30];
        int age;
        float gpa;
};
typedef struct Student Student;

int sortGPA(Student a[], int n);

int main(){
        Student a[200];
        FILE *fin = NULL;
        fin = fopen("students.txt", "r");
        if (fin == NULL) {
                printf("input file error!\n");
                exit(-1);
        }
        int i, n;
        fscanf(fin, "%d", &n); 

        for (i = 0; i < n; i++) {
                fscanf(fin, "%s %d %f", a[i].name, &a[i].age, &a[i].gpa);
        }
        fclose(fin); //fin file-d students.txt -iig unshsan

        sortGPA(a, n); //sort hiisen

        for (i = 0; i < n; i++){
                printf("%3.1f\t%d\t%s\n", a[i].gpa, a[i].age, a[i].name);
        }
        
        FILE *foyutan;
        foyutan = fopen("oyutan.txt", "w");
        if(!foyutan){
                printf("aldaa\n");
                exit(1);
        }
        for(i = 0; i < n; i++){
                fprintf(foyutan, "%.1f %s %d\n", a[i].gpa, a[i].name, a[i].age);
        }
        fclose(foyutan);
        return 0;
}
int sortGPA(Student a[], int n){
        for(int i = 0; i < n-1; i++){
                int m = i;
                for(int j = i+1; j < n; j++){
                        if(a[j].gpa > a[m].gpa){
                                m = j;
                        }
                }
                if(m != i){
                        Student d = a[i];
                        a[i] = a[m];
                        a[m] = d;
                }   
        //дүнгээр нь буурахаар эрэмбэлж байна.     
        }
}

#include<stdio.h>
int main(){
	int arr[] = {3, 5, 6, 7, 9};
	int *p = arr; //buhel toon neg elementiig zaah zaagch int
	int (*ptr)[5] = &arr; //5uurttai massiwiig zaah zaagch
	
	printf("p = %p, ptr = %p\n", p, ptr);
	printf("*p = %d, *ptr = %p\n", *p, *ptr);
	printf("sizeof(arr) = %lu, sizeof(arr[0]) = %lu\n",sizeof(arr), sizeof(arr[0]));
	printf("sizeof(p) = %lu, sizeof(*p) = %lu\n",sizeof(p), sizeof(*p));
	printf("sizeof(ptr) = %lu, sizeof(*ptr) = %lu\n",sizeof(ptr), sizeof(*ptr));
	
	return 0;
}

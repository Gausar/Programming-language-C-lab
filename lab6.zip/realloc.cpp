#include<stdio.h>
#include<stdlib.h>

int main(){
	//nootsloson sanah oin hayagiig hadgalah zaagch
	int* ptr;
	int n,i;
	//ekhniii nootsloh sanah oin hemjee
	n = 5;
	printf("elementiin toogoo oruulna uu: %d\n",n);
	
	//calloc() ashiglan ogogodson hemjeetei sanah oig nootsloh
	ptr = (int*)calloc(n, sizeof(int));
	
	//nootslogdson esehiig shalgaj bgaa
	//amjilttai nootslogdoogui bol NULL butsaadag tul shalgaj bna
	if(ptr == NULL){
		printf("memory not allocarted.\n");
		exit(0);
	}
	else {
		//amjilttai nootslogdson bol medegdeh
		printf("memory successfullty allocated using calloc.\n");
		
		//nootslogdson sanah oid utga onooh
		for(i=0; i<n; i++){
			ptr[i] = i+1;
		}
		//hewleh
		printf("husnegtiin elementuud ni : ");
		for(i=0; i<n; i++){
			printf("%d, ", ptr[i]);
		}
		//omno nootslososn sanah oin hemjeeg oorchloh hemjeeg awah
		n=10;
		//ogoogdson shine hemjeegeer sanah oin hemjeeg oorchloh
		ptr = realloc(ptr, n * sizeof(int));
		//amjilttai nootslohgdson bol
		printf("Memory successfullyt re-allocated using realloc.\n");
		
		//nootslogdso sanah oid utga onooh
		for(i=0; i<n; ++i){
			ptr[i] = i+1;
		}
		//nootslogdson sanah oig cholooloh
		free(ptr);
	}
	return 0;
}

#include<stdio.h>
double square(double x);
double (*p)(double x);
	
int main(){
	p=square;
	printf("%f %f \n", square(1.5), p(1.5));
	return 0;
}

double square(double x){
	return x*x;
}

#include<stdio.h>
#include<string.h>

int main(){
	char temdegt[1000];
	char shine[100][100];
	int s,j,i;
	printf("oguulberee oruul\n");
	fgets(temdegt,  sizeof temdegt, stdin);
	j=0; s=0;
	printf("salgaj haruulaw\n");
	for(int i=0; i<=strlen(temdegt); i++){
		if(temdegt[i]==' '||temdegt[i]=='\0'){
			shine[s][j]='\0';
			s++;
			j=0;
		}
		else{
			shine[s][j]=temdegt[i];
			j++;
		}
	}
	
	for(i=0; i<s;i++){
		printf("%s\n", shine[i]);
	}
	return 0;
}


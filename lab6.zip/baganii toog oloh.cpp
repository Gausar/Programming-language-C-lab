#include<stdio.h>
int const NCOLUMNS = 3;

int main(){
	int n[][3]={{1, 8, 7},
				{2, 9, 10}};
	int row = sizeof(n)/sizeof(n[0]);
	printf("sizeof(n): %ld\n", sizeof(n));
	printf("sizeof(n[0]): %ld\n", sizeof(n[0]));
	
	printf("%d\n", row);
	printf("%d\n", *(*(n+1)+2));
	return 0;
}

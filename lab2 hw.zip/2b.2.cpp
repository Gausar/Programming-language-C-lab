#include<stdio.h>
#include<math.h>
int main(){
	int n,s,i;
	s=0;
	printf("niilber oloh n toogoo oruulna uu\n");
	
	scanf("%d",&n);
	
	for(i=2;i<=n;i=i+2){
		s=s+i;
	}
	
	printf("n hurtelh tegsh toonuudiin niilber %d",s);
	
	return 0;
}

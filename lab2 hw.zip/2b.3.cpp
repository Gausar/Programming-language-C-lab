#include<stdio.h>
#include<math.h>
int main(){
	
	int n,s,r;
	s=0;
	printf("N toogoo oruulaarai\n");
	scanf("%d",&n);
	while(n>0){
		r=n%10;
		s=s+r;
		n=n/10;
	}
	
	printf("tsipruudiiin niilber %d bna",s);
	return 0;
}

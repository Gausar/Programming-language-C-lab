#include<stdio.h>
int main(){
	int a,k,n;
	bool m;
	printf("4 orontoi toogoo oruulna uu\n");
	scanf("%d",&a);
	k=(a/100);
	n=(a%10)*10+((a%100)-(a%10))/10;
	
	m=(k==n);
	printf("%d\n",m);
	
	return 0;
}

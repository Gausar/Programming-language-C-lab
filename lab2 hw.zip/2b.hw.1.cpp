#include<stdio.h>
#include<math.h>
int main(){
	int n,s,i;
	printf("n toogoo oruulna uu\n");
	scanf("%d",&n);
	printf("%d -iin huvaagchid : ",n);
	
	for(i=1;i<=n;i++){
		if(n%i==0){
			printf("%d  ",i);
	}
	}
	
}

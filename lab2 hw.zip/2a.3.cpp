#include<stdio.h>
int main(){
	int a,b,c,d,e,f,g;
	printf("Gurvan toogoo oruulna uu?");
	scanf("%d%d%d",&a,&b,&c);
	//hamgiin ihiig olj bn
	(a>b)&&(a>c)&&printf("hamgiin ih %d\n",a);
	(b>a)&&(b>c)&&printf("hamgiin ih %d\n",b);
	(c>a)&&(c>b)&&printf("hamgiin ih %d\n",c);
	
	//dundaj utga
	(a>b)&&(a<c)&&printf("dundaj ni %d\n", a);
	(b>a)&&(b<c)&&printf("dundaj ni %d\n", b);
	(c>a)&&(c<b)&&printf("dundaj ni %d\n", c);
		
	//hamgiin baga utge
	(a<b)&&(a<c)&&printf("Hamgiin baga ni %d\n",a);
	(b<a)&&(b<c)&&printf("Hamgiin baga ni %d\n",b);
	(c<a)&&(c<b)&&printf("Hamgiin baga ni %d\n",c);
	
	return 0;
}

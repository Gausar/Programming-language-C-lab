#include <stdio.h>
#include <string.h>

int main()
{
    char num[11];
    int count, max_count = 0;
    int i, j, max_digit;

    printf("Enter a 10-digit number: ");
    scanf("%s", num);

    if (strlen(num) != 10)
    {
        printf("Invalid input: not a 10-digit number\n");
        return 0;
    }

    for (i = 0; i < 10; i++)
    {
        count = 0;
        for (j = 0; j < 10; j++)
        {
            if (num[j] - '0' == i)
                count++;
        }
        if (count > max_count)
        {
            max_count = count;
            max_digit = i;
        }
    }

    printf("The digit %d appears the most with %d occurrence(s).\n", max_digit, max_count);

    return 0;
}


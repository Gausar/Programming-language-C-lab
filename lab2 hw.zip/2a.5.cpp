#include<stdio.h>
int main(){
	int n;
	printf("onoo oruulna uu\n");
	scanf("%d",&n);
	if(n%400==0){
		printf("Ondor jil mon bn");
	}
	else if((n%4==0)&&(n%100!=0)){
		printf("Ondor jil mon bn");
	}
	else{
		printf("ondor jil bish bn");
	}
	
	return 0;
}

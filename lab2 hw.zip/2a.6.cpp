#include<stdio.h>
int main(){
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	if(a>b){
		if(a>b){
			printf("Hamgiin ih ni %d",a);
		}
		else printf("Hamgiin ih ni %d",c);
	}
	else if(b>c){
		printf("Hamgiin ih ni %d",b);
	}
	else printf("Hamgiin ih ni %d",c);
	
	return 0;
	}


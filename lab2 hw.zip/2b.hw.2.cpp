#include<stdio.h>
#include<math.h>
int main(){
	int a,b,max,i;
	//max=hamgiin ih huvaagch
	max=1;
	printf("hoyr toogoo oruulna uu\n");
	printf("a = ");
	scanf("%d",&a);
	printf("b = ");
	scanf("%d",&b);
	if(a<b){
	for(i=2;i<=a;i++){
		if(a%i==0){
			if(b%i==0){
				if(max<i){
				max=i;
			}}
		}
		
	}	
	printf("hamgiin ih yronhii huwaagch ni : %d bna",max);	
	}
return 0;
}

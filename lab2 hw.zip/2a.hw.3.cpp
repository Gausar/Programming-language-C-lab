#include<stdio.h>
int main(){
	int A;
	printf("Shalgah toogoo oruulna uu?\n");
	scanf("%d",&A);
	
	if(A%2==0){
		printf("Tegsh too bna\n");
		//10ba 4t zereg huwaagdana gdg ni 20 d huwaagdah too gsn ug
		if(A%20==0){
			printf("10 ba 4-t huwaagdah too bna\n");
		}
		else printf("10 ba 4-t huwaagdahgui too bna\n");
	}
	else {
	printf("Sondgoi too bna\n");
	if(A%21==0){
			printf("3 ba 7-t huwaagdah too bna\n");
		}
		else printf("3 ba 7-t huwaagdahgui too bna\n");
}
return 0;
}

#include<stdio.h>
#include<math.h>
int main(){
	long long int a,k,d,b;
	printf("10 orontoi buhel toogoo oruulna uu?\n");
	scanf("%lld",&a);
	
	int tooluur=1;
	int max=0;
	while(a>0){
		k=a%10;
		b=a/10;
		while(b>0){
		if(b%10==k)
		{
			tooluur++;
		}
		b=b/10; 
		}
		if(tooluur>max){
			max=tooluur;
			d=k;
		}
	tooluur=1;
	a=a/10;	
	}
	printf("Hamgiin olon dawtagdsan too %d ba %d udaa orson bn",d,max);
	
	return 0;
	}
	

#include<stdio.h>
int main(){
	float k,p;
	printf("Dungee oruulna uu\n");
	scanf("%f",&k);
	p=(k*100)/35;
	printf("Tanii shalgaltiin unelgee : ");
	if(p>=90){
		printf("A");
	}
	else if(p>=80){
		printf("B");		
	}
	else if(p>=70){
		printf("C");
	}
	else if(p>=60){
		printf("D");
	}
	else printf("F");
	return 0;
}

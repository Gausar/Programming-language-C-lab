#include<stdio.h>

int main(){
	int a,b,c,d;
	scanf("%d%d", &a,&b);
	c=(a>b)*a+(a<=b)*b;
	d=(a<b)*a+(a>=b)*b;
	
	printf("baga ni %d\n",d);
	printf("ih ni %d\n",c);
}

#include<stdio.h>
int main(){
	int a,b,c;
	/*c=15,
	a=12,
	b<15 utguud awna
	
	*/
	scanf("%d%d%d",&a,&b,&c);
	c<b&&a<c&&printf("bolj ");
	(a%3 == 0 || c%5 ==3)&& printf("bna.\n");
	
}

#include<stdio.h>
int main(){
	int a,b,c;
	printf("Gurvaljnii taluudiin urtiig oruulna uu\n");
	scanf("%d%d%d",&a,&b,&c);
	(a==b)&&(b==c)&&(a==c)&&printf("Zow gurvaljin bna");
	
	(a==b)||(a==c)||(b==c)&&printf("Adil hajuut gurvaljin bna");
	
	(a!=b)&&(a!=c)&&(b!=c)&&printf("Eldev talt gurvaljin bna");
	
	return 0;
}
